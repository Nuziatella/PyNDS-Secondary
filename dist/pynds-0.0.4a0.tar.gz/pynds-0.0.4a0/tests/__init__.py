"""Test suite for PyNDS - ensuring it works correctly!

This package contains all the tests to make sure PyNDS behaves correctly
and doesn't break.
"""
